/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright (C) August 2019 by Kaj Wortel - all rights reserved             *
 * Contact: kaj.wortel@gmail.com                                             *
 *                                                                           *
 * This file is part of the tools project, which can be found on github:     *
 * https://github.com/Kaj0Wortel/tools                                       *
 *                                                                           *
 * It is allowed to use, (partially) copy and modify this file               *
 * in any way for private use only by using this header.                     *
 * It is not allowed to redistribute any (modified) versions of this file    *
 * without my permission.                                                    *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package tools;


// Java imports
import java.awt.Insets;
import java.text.AttributedString;
import java.util.Iterator;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;


// Tools imports
import tools.data.array.ArrayTools;
import tools.data.file.FileTree;
import tools.data.img.BoundedImageSheet;
import tools.data.img.QuadrupleGUIImageSheet;
import tools.data.img.GUIImageSheet;
import tools.data.img.ManagedImageSheet;
import tools.data.img.OverlayImageSheet;
import tools.gui.SheetButton;
import tools.data.img.managed.ImageManager;
import tools.font.FontLoader;
import tools.gui.EditField;
import tools.iterators.RandomIterator;
import tools.log.Logger;
import tools.log.StreamLogger;


/**
 * 
 * 
 * @author Kaj Wortel
 */
public class Test {
    
    private static final FileTree ft = FileTree.getLocalFileTree();
    
    private static final String TEST_SQUARE = Var.L_IMG_DIR + "test_square.png";
    private static final String OVERLAY = Var.L_IMG_DIR + "border_type_1" + Var.FS + "content_button_TYPE_001_overlay.png";
    private static final String BUTTON_DEF = Var.L_IMG_DIR + "border_type_1" + Var.FS + "content_button_TYPE_001_u_def.png";
    private static final String BUTTON_OVER = Var.L_IMG_DIR + "border_type_1" + Var.FS + "content_button_TYPE_001_u_over.png";
    private static final String BUTTON_PRESS = Var.L_IMG_DIR + "border_type_1" + Var.FS + "content_button_TYPE_001_u_press.png";
    private static final String BUTTON_DIS = Var.L_IMG_DIR + "border_type_1" + Var.FS + "content_button_TYPE_001_u_dis.png";
    
    public static void main(String[] args) {
        try {
            //MultiTool.initLogger(Var.LOG_FILE);
            Logger.setDefaultLogger(new StreamLogger(System.out));
            FontLoader.syncLoad();
            run();
            
        } catch (Exception e) {
            Logger.write(e);
            
        } finally {
            //MultiTool.sleepThread(5000);
            //System.exit(0);
        }
    }
    
    
    public static void run2() {
        JFrame frame = new JFrame("test");
        frame.setLayout(null);
        
        final EditField ef = new EditField();
        ef.setBounds(50, 50, 200, 25);
        ef.addListener((e) -> {
            Document doc = e.getDocument();
            try {
                String text = doc.getText(0, doc.getLength());
                if (text.contains("a")) {
                    ef.setError();
                } else {
                    ef.clearError();
                }
                ef.repaint();
                
            } catch (BadLocationException ex) {
                System.err.println(e);
            }
        });
        frame.add(ef);
        
        frame.setBounds(50, 50, 300, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    
    
    
    public static void run()
            throws Exception {
        JFrame frame = new JFrame("test");
        frame.setLayout(null);
        frame.setSize(600, 600);
        
        FileTree ft = FileTree.getLocalFileTree();
        BoundedImageSheet overlay = new ManagedImageSheet(ft, OVERLAY, 16, 16);
        BoundedImageSheet def = new OverlayImageSheet(3, 3, new ManagedImageSheet(ft, BUTTON_DEF, 16, 16), overlay);
        BoundedImageSheet over = new OverlayImageSheet(3, 3, new ManagedImageSheet(ft, BUTTON_OVER, 16, 16), overlay);
        BoundedImageSheet press = new OverlayImageSheet(3, 3, new ManagedImageSheet(ft, BUTTON_PRESS, 16, 16), overlay);
        BoundedImageSheet dis = new OverlayImageSheet(3, 3, new ManagedImageSheet(ft, BUTTON_DIS, 16, 16), overlay);
        
        GUIImageSheet guiSheet = new QuadrupleGUIImageSheet(def, over, press, dis);
        Insets in = new Insets(20, 20, 20, 20);
        SheetButton button = new SheetButton(in, guiSheet, "test string bla bla bla bla bla bla bla bla");
        button.addActionListener((e) -> {
            //button.setEnabled(!button.isEnabled());
        });
        button.setSize(400, 400);
        button.setLocation(100, 100);
        frame.add(button);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        
        //MultiTool.sleepThread(1000);
        //button.setFont(FontLoader.getFont("Cousine-Bold.ttf", 30f));
    }
    
    
}
